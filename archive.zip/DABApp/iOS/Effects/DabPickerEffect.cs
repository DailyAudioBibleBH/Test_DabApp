﻿//using System;
//using DABApp.iOS;
//using UIKit;
//using Xamarin.Forms;
//using Xamarin.Forms.Platform.iOS;

//[assembly: ResolutionGroupName("DabEffects")]
//[assembly: ExportEffect(typeof(DabPickerEffect), "DabPickerEffect")]
//namespace DABApp.iOS
//{
//	public class DabPickerEffect: PlatformEffect
//	{
//		protected override void OnAttached()
//		{
//			var picker = (UITextField)Control;
//			picker.Font = UIFont.SystemFontOfSize((nfloat)Device.GetNamedSize(NamedSize.Large, typeof(Label)) );
//		}

//		protected override void OnDetached()
//		{
//			throw new NotImplementedException();
//		}
//	}
//}
