﻿//using System;
//namespace DABApp.iOS
//{
//	public class SocketHelper
//	{
//		public string html { get; set;} 
//		public string date { get; set;}
//		public string token { get; set;}

//		public SocketHelper(string Date, string Token)
//		{
//			date = Date;
//			token = Token;
//		}

//		public SocketHelper(string Html, string Date, string Token)
//		{
//			html = Html;
//			date = Date;
//			token = Token;
//		}
//	}
//}
