﻿using System;
using Xamarin.Forms;

namespace DABApp
{
	public class AudioOutputView: Xamarin.Forms.View
	{
		public AudioOutputView()
		{ 
			
		}
	}
}
