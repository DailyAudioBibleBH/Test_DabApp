﻿using System;
using SlideOverKit;

namespace DABApp
{
	public class HomePage: MenuContainerPage
	{
		public HomePage()
		{
		}
	}
}
