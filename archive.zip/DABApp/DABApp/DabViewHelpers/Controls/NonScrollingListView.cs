﻿using System;
using Xamarin.Forms;

namespace DABApp
{
	public class NonScrollingListView : ListView
	{
		public NonScrollingListView()
		{
		}
	}
}
