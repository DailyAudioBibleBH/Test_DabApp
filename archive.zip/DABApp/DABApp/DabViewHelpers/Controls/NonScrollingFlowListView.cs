﻿using System;
using DLToolkit.Forms.Controls;

namespace DABApp
{
	public class NonScrollingFlowListView: FlowListView
	{
	}
}
