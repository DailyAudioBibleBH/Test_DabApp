﻿using System;
using Xamarin.Forms;

namespace DABApp
{
	public class DarkKeyboardEntry: Entry
	{
	}

	public class DarkKeyboardEditor : Editor { }
}
