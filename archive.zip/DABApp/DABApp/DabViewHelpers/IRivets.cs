﻿using System;

namespace DABApp
{
	public interface IRivets
	{
		void NavigateTo(string Url);
	}
}
