﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DABApp.Interfaces
{
    public interface IAppVersionName
    {
        string GetVersionName();
    }
}
