﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace DABApp
{
	public partial class DabTestPage : ContentPage
	{
		public DabTestPage()
		{
			//InitializeComponent();
		}
	}
}
