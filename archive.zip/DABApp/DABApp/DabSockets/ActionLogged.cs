﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DABApp.DabSockets
{
    public class ActionLogged
    {
        public Action action { get; set; }

        public ActionLogged(Action action)
        {
            this.action = action;
        }
    }
}
