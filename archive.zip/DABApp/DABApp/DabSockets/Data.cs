﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DABApp.DabSockets
{
    public class Data
    {
        public ActionLogged actionLogged { get; set; }

        public Data(ActionLogged actionLogged)
        {
            this.actionLogged = actionLogged;
        }
    }
}
