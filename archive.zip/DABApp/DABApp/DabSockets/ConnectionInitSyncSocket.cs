﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DABApp.DabSockets
{
    public class ConnectionInitSyncSocket
    {
        public string type { get; set; }
        public string id { get; set; }
        public Payload payload { get; set; }

        public Action action { get; set; }

        public ConnectionInitSyncSocket(string type, Action action)
        {
            this.type = type;
            this.action = action;
        }

        public ConnectionInitSyncSocket(string type, string id, Payload payload)
        {
            this.type = type;
            this.id = id;
            this.payload = payload;
        }
    }
}
