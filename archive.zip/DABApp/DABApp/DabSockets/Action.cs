﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DABApp.DabSockets
{
    public class Action
    {
        public int userId { get; set; }
        public int episodeId { get; set; }
        public bool listen { get; set; }
        public object position { get; set; }
        public bool favorite { get; set; }
        public object entryDate { get; set; }
        public string x_token { get; set; }

        public Action(string x_token)
        {
            this.x_token = x_token;
        }

        public Action(int episodeId, bool listen, object position, bool favorite, object entryDate)
        {
            this.episodeId = episodeId;
            this.listen = listen;
            this.position = position;
            this.favorite = favorite;
            this.entryDate = entryDate;
        }
    }
}
